from flask import Flask, jsonify, send_file, request, Response
import logging
from flask_cors import CORS

application = Flask(__name__)
CORS(application)

@application.route('/skills', methods=['GET'])
def getSkills():
    skills=[{"title":'Coordination'},{"title": 'Analysis'},{"title": 'Marketing'},{"title": 'Programming'},{"title": 'Planning'}]
    return jsonify(skills)


@application.route('/jobs', methods=['GET'])
def getJobs():
    jobs=[{"title":'Project Coordinator',"entries": 2 },{'title':'Junior Business Analyst',"entries": 2},{"title":'Entry Level Marketing Assistant',"entries": 1},
                  {"title": 'Program Assistant',"entries": 1},{"title":'Assistant Planner',"entries": 1}]
    return jsonify(jobs)


@application.route('/industries', methods=['GET'])
def getIndustries():
    industries=[{"title":'Financial Services',"entries": 4},{"title":'Marketing and Advertising, Public Relations and Communications, Management Consulting',"entries": 2 },
                {"title":'Nonprofit Organization Management, Higher Education, Education Management',"entries": 2},{"title": 'Consumer Goods',"entries": 2},
                {"title": 'Real Estate',"entries":1}]
    return jsonify(industries)



@application.route("/")
def hello():
    return "Welcome to Key Learning"


if __name__ == "__main__":
    application.debug = True
    application.run()
